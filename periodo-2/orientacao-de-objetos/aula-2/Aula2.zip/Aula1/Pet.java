public class Pet{
	String especie;
	String nome;
	int idade;
}
