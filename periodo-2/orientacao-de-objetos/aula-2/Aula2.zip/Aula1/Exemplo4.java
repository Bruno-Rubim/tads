public class Exemplo4{
	public static void main(String[] args){
		
		OperacoesMatematicas opMat = new OperacoesMatematicas();
		System.out.println("5 + 6 = " + opMat.somar(5,6));
	}
}
