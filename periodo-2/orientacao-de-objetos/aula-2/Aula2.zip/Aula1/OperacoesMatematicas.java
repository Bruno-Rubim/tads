public class OperacoesMatematicas{
	//comentario de uma linha
	public int somar(int num1, int num2){
		return num1 + num2;
	}
	
	public int subtrair(int num1, int num2){
		return num1 - num2;
	}
	
	public int multiplicar(int num1, int num2){
		return num1 * num2;
	}
	
	public float dividir(int num1, int num2){
		return num1 / num2;
	}
	
	/*
	 bloco de comentario
	 */
}
