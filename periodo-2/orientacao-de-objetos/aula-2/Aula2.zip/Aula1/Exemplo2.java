public class Exemplo2{
	public static void main(String[] args){
		System.out.println("O parâmetro informado foi " + args[0]);
	}
}
